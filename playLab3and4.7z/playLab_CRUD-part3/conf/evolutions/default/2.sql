# --- Sample dataset

# --- !Ups

insert into product (id,name,category,description,stock,price) values ( 1,'Kettle','Kitchen','Steel Electric Kettle',100,55.00 );
insert into product (id,name,category,description,stock,price) values ( 2,'Fridge freezer','Kitchen','Fridge + freezer large',45,799.00 );
insert into product (id,name,category,description,stock,price) values ( 3,'Portable Music Player','Audio Visual','250GB music player (MP3,MP4,WMA,WAV)',5,99.00 );
insert into product (id,name,category,description,stock,price) values ( 4,'13inch Laptop','Computer','HP laptop,8GB RAM,250GB SSD',45,799.00 );
insert into product (id,name,category,description,stock,price) values ( 5,'8inch Tablet','Mobile','Android 5.1 Tablet,32GB storage,8inch screen',5,99.00 );
insert into product (id,name,category,description,stock,price) values ( 6,'46inch TV','Audio Visual','Sony 4K,OLED,Smart TV',12,2799.00 );
insert into product (id,name,category,description,stock,price) values ( 7,'Washing Machine','Laundry','1600rpm spin,A+++ rated,10KG',50,699.00 );
insert into product (id,name,category,description,stock,price) values ( 8,'Phone','Mobile','Android 6,5.2inch OLED,3GB RAM,64GB Storage',45,799.00 );
insert into product (id,name,category,description,stock,price) values ( 9,'10inch Tablet','Mobile','Windows 10,128GB storage,8inch screen',5,299.00 );
insert into product (id,name,category,description,stock,price) values ( 10,'Oven','Kitchen','Oven + Grill,Stainless Steel',10,399.00 );
insert into product (id,name,category,description,stock,price) values ( 11,'Bed','Furniture','Super King size,super comfort mattress',5,899.00 );
insert into product (id,name,category,description,stock,price) values ( 12,'Learning JavaScript','Books','Become a JavaScript expert in 2 hours!',50,29.00 );
